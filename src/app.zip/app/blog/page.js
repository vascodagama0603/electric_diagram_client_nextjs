// /app/blog/page.js (Next.js App Router の場合)

"use client";
import { BlogCatalog } from './components/BlogCatalog';

export default function BlogPage() {
    return (
        <>
            <BlogCatalog />
        </>
    );
}