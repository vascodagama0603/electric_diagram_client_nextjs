// BlogCatalog.jsx
"use client";

import React, { useState, useEffect } from 'react';
import styled from "@emotion/styled";
import { getBlogArticles } from './lib/blogClient'; 

// --- Styled Components 定義 ---

const BlogPageTitle = styled.h2`
    font-size: 2rem;
    color: #333;
    margin: 10px 0 30px 0;
    border-bottom: 3px solid #e74c3c; /* ブログ用のアクセントカラー */
    padding-bottom: 5px;
`;

const BlogContainer = styled.div`
    padding: 10px 0;
    display: flex;
    flex-direction: column;
    gap: 30px;
`;

const BlogArticleCard = styled.a`
    display: flex;
    background-color: #ffffff;
    border: 1px solid #e0e0e0;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    text-decoration: none;
    color: inherit;
    transition: all 0.3s ease-in-out;
    cursor: pointer;
    
    &:hover {
        box-shadow: 0 8px 20px rgba(231, 76, 60, 0.2); /* ホバー時の影を赤系に */
        transform: translateY(-5px);
        border-color: #e74c3c; /* ホバーで赤系に */
    }

    @media (max-width: 768px) {
        flex-direction: column;
    }
`;

const ArticleImage = styled.div`
    width: 300px;
    min-width: 300px; 
    height: 200px;
    /* 仮の背景色。実際にはURLプロパティから画像を読み込みます */
    background: #f1f1f1 url(${(props) => props.src}) center center / cover; 
    
    @media (max-width: 768px) {
        width: 100%;
        height: 180px;
        min-width: unset;
    }
`;

const ArticleContent = styled.div`
    padding: 20px 30px;
    flex-grow: 1;
`;

const ArticleTitle = styled.h3`
    font-size: 1.6rem;
    color: #333;
    margin-top: 0;
    margin-bottom: 10px;
`;

const ArticleSummary = styled.p`
    font-size: 1rem;
    color: #555;
    line-height: 1.6;
    margin-bottom: 15px;
`;

const ArticleMeta = styled.div`
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.85rem;
    color: #888;
    border-top: 1px dashed #eee;
    padding-top: 10px;
`;

const TagList = styled.div`
    display: flex;
    gap: 8px;
`;

const Tag = styled.span`
    background-color: #fcecec; 
    color: #e74c3c; /* 赤系のアクセント */
    padding: 4px 8px;
    border-radius: 4px;
    font-weight: 600;
    font-size: 0.8rem;
`;

const StatusMessage = styled.div`
    text-align: center;
    padding: 50px;
    font-size: 1.2rem;
    color: ${(props) => (props.loading ? '#007bff' : '#6c757d')};
`;

// --- メインコンポーネント ---

export function BlogCatalog() {
    const [articles, setArticles] = useState([]);
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchArticles = async () => {
            setIsLoading(true);
            const data = await getBlogArticles(); 
            setArticles(data);
            setIsLoading(false);
        };
        fetchArticles();
    }, []);

    const formatDate = (dateString) => {
        if (!dateString) return '日付不明';
        const options = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('ja-JP', options);
    };

    return (
        <>
            <BlogPageTitle>💡 電気設計 技術ブログ</BlogPageTitle>
            
            {/* 💡 ロード中の表示 */}
            {isLoading && (
                <StatusMessage loading>記事をロード中です...</StatusMessage>
            )}

            {/* 💡 記事がない場合の表示 (ロード完了後) */}
            {!isLoading && articles.length === 0 && (
                <StatusMessage>現在、公開されている記事はありません。</StatusMessage>
            )}
            
            {/* 💡 記事一覧の表示 */}
            {!isLoading && articles.length > 0 && (
                <BlogContainer>
                    {articles.map((article) => (
                        <BlogArticleCard 
                            key={article.slug} 
                            // 記事詳細ページへのリンク（Next.jsでは <Link href={`/blog/${article.slug}`} > を使用します）
                            href={`/blog/${article.slug}`} 
                        >
                            <ArticleImage src={article.image || '/default-blog-image.jpg'} />
                            <ArticleContent>
                                <ArticleTitle>{article.title}</ArticleTitle>
                                <ArticleSummary>{article.summary}</ArticleSummary>
                                <ArticleMeta>
                                    <span>{formatDate(article.date)}</span>
                                    <TagList>
                                        {article.tags.map(tag => (
                                            <Tag key={tag}>{tag}</Tag>
                                        ))}
                                    </TagList>
                                </ArticleMeta>
                            </ArticleContent>
                        </BlogArticleCard>
                    ))}
                </BlogContainer>
            )}
        </>
    );
}